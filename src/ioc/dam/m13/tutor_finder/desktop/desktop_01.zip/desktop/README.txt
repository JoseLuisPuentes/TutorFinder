Paquet per posar la part d'escriptori.
